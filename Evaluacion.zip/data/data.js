const data = [
	{
		id: 1,
		descripcion: "esto es una descripcion",
		foto: "https://upload.wikimedia.org/wikipedia/commons/0/0f/Isla_Tenglo_%2825845696522%29.jpg",
		nombre: "isla tenglo",
	},
	{
		id: 2,
		descripcion: "Isla grande de chiloe ",
		foto: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpW94_Pchq1noVzApZhm30yMKR7GOr-BNmhw&s",
		nombre: "isla chiloe",
	},
];

export default data;
