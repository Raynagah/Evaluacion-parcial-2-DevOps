import React from 'react';

export default function Texto({ texto }) {
  return <p> {texto} </p>;
}
